package ATCAssignment.steps;

import org.openqa.selenium.WebDriver;
import ATCAssignment.pages.WomenShoppingPage;

public class WomenShoppingSteps {
	
	WomenShoppingPage womenShoppingPage;
	
	public WomenShoppingSteps(WebDriver driver) {
		womenShoppingPage = new WomenShoppingPage(driver);
	}
	
	public void navigateToSummerDresses() {
		womenShoppingPage.mouseOverWomen();
		womenShoppingPage.clickSummerDresses();
	}
}
