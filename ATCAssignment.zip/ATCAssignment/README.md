USAGE:
Import as maven project.


Execution:
Run the project using TestRunner Class and Run as JUnit.

